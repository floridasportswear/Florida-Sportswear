FLORIDA SPORTSWEAR — WEBSITE STARTER (UPDATED)

Files:
- index.html: responsive storefront with product search, category filters, cart, and a clearly labelled checkout preview.
- This is still a static demo. The checkout preview does not send or save customer data and does not take payments.

FREE HOSTING:
1. Sign in/create a GitHub account: https://github.com/
2. Create a public repository named florida-sportswear.
3. Upload index.html into the repository root.
4. Go to Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select branch main and folder /(root), then Save.
6. Wait for the published URL to appear on the Pages settings screen.

ONLINE PAYMENTS IN BANGLADESH:
- Compare official provider options and apply directly. SSLCOMMERZ supports hosted checkout and has published a Basic price of ৳25,500 one-time plus 2.5% per successful transaction (3.5% for AMEX), so this is NOT a zero-cost live-payment solution. Confirm current terms with the provider.
- bKash offers online business/payment gateway solutions; contact them to confirm eligibility, required documents, fees, and whether your business can be approved.
- Provider integration requires a secure server/backend. Never put secret API keys in index.html or any public GitHub repository.
- A real integration must create payment sessions server-side, validate the transaction with the provider, handle payment notifications/webhooks, and save orders securely.
- Do not collect card details directly in this website.
- Before taking real orders, replace sample products/prices/photos and sample shipping/returns claims, add real business contact details, and publish privacy, delivery, refund/return, and terms policies.

OFFICIAL PROVIDER LINKS:
SSLCOMMERZ pricing: https://sslcommerz.com/pricing/
SSLCOMMERZ integration docs: https://sslcommerz.com/integration-document/
bKash online business: https://www.bkash.com/en/business

A free static website is suitable for displaying the store, but live online payments, secure order storage, and stock management require additional services and setup. The website is not payment-ready yet.
